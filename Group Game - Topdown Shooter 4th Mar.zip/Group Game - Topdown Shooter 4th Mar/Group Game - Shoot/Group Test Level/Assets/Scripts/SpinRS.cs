﻿using UnityEngine;
using System.Collections;

public class SpinRS : MonoBehaviour {

    public enum RotationAxes { JoystickXAndY = 0, JoystickX = 1, JoystickY = 2 }
    public RotationAxes axes = RotationAxes.JoystickXAndY;
    public float mousesensitivityX = 15F;
    public float mousesensitivityY = 15F;

    public float joysensitivityX = 3F;
    public float joysensitivityY = 3F;

    public float minimumX = -360F;
    public float maximumX = 360F;

    public float minimumY = -60F;
    public float maximumY = 60F;

    float rotationY = 0F;

    // Use this for initialization
    void start()
    {
        // Make the rigid body not change rotation
        Rigidbody rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {

        float Xon = Mathf.Abs(Input.GetAxis("Joystick X"));
        float Yon = Mathf.Abs(Input.GetAxis("Joystick Y"));

        if (axes == RotationAxes.JoystickXAndY)
        {
            float rotationX = transform.localEulerAngles.y + Input.GetAxis("Joystick X") * mousesensitivityX;

            rotationY += Input.GetAxis("Joystick Y") * mousesensitivityY;
            rotationY = Mathf.Clamp(rotationY, minimumY, maximumY);

            transform.localEulerAngles = new Vector3(-rotationY, rotationX, 0);
        }
        else if (axes == RotationAxes.JoystickX)
        {
            if (Xon > .05)
            {
                transform.Rotate(0, Input.GetAxis("Joystick X") * joysensitivityX, 0);
            }
            transform.Rotate(0, Input.GetAxis("Joystick X") * mousesensitivityX, 0);
        }
        else
        {
            if (Yon > .05)
            {
                rotationY += Input.GetAxis("Joystick Y") * joysensitivityY;
            }
            rotationY += Input.GetAxis("Joystick Y") * mousesensitivityY;
            rotationY = Mathf.Clamp(rotationY, minimumY, maximumY);

            transform.localEulerAngles = new Vector3(-rotationY, transform.localEulerAngles.y, 0);

        }
    }
}