﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof (CharacterController))] //Makes the script unable to run without the CharacterController component
public class PlayerMovement : MonoBehaviour {

    private CharacterController controller; //Makes the CharacterController a variable

    //private Quaternion targetRotation; //CURRENTLY ONLY SET TO LOOK WHERE THE PLAYER IS MOVING, NOT WHERE THE MOUSE/RIGHT ANALOGUE STICK IS POINTING
    //public float rotationSpeed = 450; //How fast the player will rotate
    public float speedWalk = 8; //How fast the player will move normally
    public float speedSprint = 11; //How fast the player will move while the sprint button is pressed

    void Start ()
    {
        controller = GetComponent<CharacterController>(); //Enabling the CharacterController to be called by the code
	}

    void Update()
    {
        Vector3 playerinput = new Vector3(Input.GetAxisRaw("Horizontal"), 0, Input.GetAxisRaw("Vertical")); //These include both "WASD" and the left analogue stick on gamepad

        if(playerinput != Vector3.zero) //If there is input from the player...
        {
            //targetRotation = Quaternion.LookRotation(playerinput); //Quarternion rotation
            //transform.eulerAngles = Vector3.up * Mathf.MoveTowardsAngle(transform.eulerAngles.y, targetRotation.eulerAngles.y, rotationSpeed * Time.deltaTime); //eulerAngles for player rotation
        }
        Vector3 motion = playerinput; //Making a new Vector3 variable for motion
        motion *= (Mathf.Abs(playerinput.x) == 1 && Mathf.Abs(playerinput.z) == 1) ? .7f : 1; //If the absolute value of input.x is equal to 1 AND the same for z, then multiply by 7
        motion *= (Input.GetButton("Run")) ? speedSprint : speedWalk; //If the Sprint button is being pressed, use the speedSprint, otherwise use speedWalk
        motion += Vector3.up * -8; //Gravity

        controller.Move(motion * Time.deltaTime); //Calling the player to move every frame
    }
}
