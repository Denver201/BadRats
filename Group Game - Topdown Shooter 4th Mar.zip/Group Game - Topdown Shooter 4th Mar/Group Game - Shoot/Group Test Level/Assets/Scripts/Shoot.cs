﻿using UnityEngine;
using System.Collections;

public class Shoot : MonoBehaviour
{
    public GameObject bulletPrefab;
    public Transform bulletSpawn;
    public int ShootSpeed;
    public float KillBullet;
    public float bulletDelay;
    private float nextFire;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        // Fire using RT
        if (Input.GetAxis("Fire1") == 1 && Time.time > nextFire)
        {
            nextFire = Time.time + bulletDelay;
            Fire();
        }
        // Fire using mouse
        if (Input.GetMouseButton(0) && Time.time > nextFire)
        {
            nextFire = Time.time + bulletDelay;
            Fire();
        }
    }
    void Fire()
    {
        // Create the Bullet from the Bullet Prefab
        var bullet = (GameObject)Instantiate(
            bulletPrefab,
            bulletSpawn.position,
            bulletSpawn.rotation);
        //Debug.Log("Spawn");
        // Add velocity to the bullet
        bullet.GetComponent<Rigidbody>().velocity = bullet.transform.TransformVector(0, ShootSpeed, 0);
        //Debug.Log("shoot");
        // Destroy the bullet
        Destroy(bullet, KillBullet);
        //Debug.Log("Dead");
    }
}
