﻿using UnityEngine;
using System.Collections;

public class BasicCameraFollow : MonoBehaviour {

    public Transform player; //The player object (soon to be prefab to allow for respawning)
    public Vector3 offset; //Offset from the player's position
    float nextTimeToSearch = 0; //Interval between searching for the player (useful for when the player dies and respawns later)
    void Start()
    {
        Time.timeScale = 1; //Unpauses the game as soon as the scene is loaded

    }


    void Update()
    {
        if (player == null) //If the player transform variable made above is null (i.e when the player dies and the object is deleted)
        {
            FindPlayer(); //Run the function below called "FindPlayer"
            return; //Returns to the update function to complete the rest of the code within the update function
        }
        transform.position = new Vector3(player.position.x + offset.x, player.position.y + offset.y, player.position.z + offset.z); //Every frame, update the position of the camera to match the player's
    }
    void FindPlayer() //Will be ran when the player dies/isn't already assigned to the player Transform variable
    {
        if (nextTimeToSearch <= Time.time) //If the time to search is less than or equal to updates...
        {
            GameObject searchResult = GameObject.FindGameObjectWithTag("Player"); //Creating a new variable called searchResult and making it be equal to the object with the player tag
            if (searchResult != null) // If the search was successful...
            {
                player = searchResult.transform; //player Transform variable is not equal to the searchResult
                nextTimeToSearch = Time.time + 0.5f; // Changes the search interval to 0.5s so the search function isn't so taxing on frame rate
            }
        }
    }
}
